package taskManager.display;

public interface DisplayFile{

	/**Method for writing to out file from observers*/
    public void writeToFile();
}
